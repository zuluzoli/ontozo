local sprinkler = {}

local io = require "io"
local nixio = require "nixio"


sprinkler.printFile = function( filename )
  local f = io.open( '/www/sprinkler/' .. filename, "r" )
  if f == nil then
    print( "<p>Can't open " .. filename .. "</p>" )
  else
    local line = f:read()
    while line ~= nil do
      print( line )
      line = f:read()
   end
    f:close()
  end
end

sprinkler.writeSerial = function( filename )
  local f = io.open( '/www/sprinkler/static/' .. filename, "r" )
  local p = io.open( '/dev/ttyUSB0', "a" )
  if f ~= nil and p ~= nil then
    local line = f:read()
    p:write( "dat" .. os.date( "%Y%m%d%H%M%S" ) .. "e" )
    while line ~= nil do
      p:write( line )
      line = f:read()
   end
    f:close()
    p:close()
  end
end

sprinkler.getValQuery = function( varname )
  local value
  local query = nixio.getenv( 'QUERY_STRING' )
  if query ~= nil then
    query = '&' .. query
    varname = '&' .. varname .. '='
    local p, q = string.find( query, varname )
    if q ~= nil then
      p = string.find( query, '&', q )
      if p == nil then p = -1 else p = p - 1 end
      value = string.sub( query, q + 1, p - 3 )
    end
  end
  value = value or 'No such variable'
  return value
end


sprinkler.writeDataFile = function( filename, data )
  local f = io.open( '/www/sprinkler/' .. filename, "w+" )
  if f ~= nil then
    io.output( f )
    io.write( data )
    io.close( f )
    return "success"
  else
    return "error"
  end
end

return sprinkler 
